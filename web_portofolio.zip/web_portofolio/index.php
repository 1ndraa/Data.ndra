<?php  
header('location: home')
?>